
import { GoogleGenAI, Chat } from "@google/genai";
import { Message } from "../types";
import { findCampaignByDate } from "../data/campaigns";

export function buildInitialMessage(
  leadName: string = 'Juan',
  daysAgo: number = 4,
  eventName: string = 'los Juegos de Invierno de Excel'
): string {
  return `¡Hola ${leadName}! 👋 Qué bueno saludarte. Antes de nada permíteme presentarme, soy Miguel MVP de Microsoft EXCEL y CEO de ExcelyFinanzas, por si no te acuerdas de mi ya que han pasado ${daysAgo} días.

Te vi súper conectado en los directos de ${eventName} y me encantó ver tu interés en dominar Excel. ❄️

Me quedé con una duda y por eso te escribo... vi que estuviste a tope con nosotros, pero al final no terminaste de dar el paso para asegurar tu plaza. Me gustaría entenderte mejor, ¿qué fue lo que te detuvo en ese momento? Cuéntame con total confianza, de verdad. 😊 Corregir cualquier duda que tengas es lo primero.`;
}

const SYSTEM_INSTRUCTION = `
Eres Miguel, MVP de Microsoft Excel y CEO de ExcelyFinanzas. Estás chateando por WhatsApp directamente con un alumno o lead potencial que asistió a los directos de tu último lanzamiento.

TU IDENTIDAD:
- Nombre: Miguel.
- Título: MVP de Microsoft Excel y CEO de ExcelyFinanzas.
- Hablas siempre en primera persona ("he diseñado", "mis directos", "en ExcelyFinanzas", "te entiendo perfectamente").
- Tono: Muy empático, cercano, profesional pero cálido (estilo WhatsApp con saltos de línea y emojis naturales). No suenes a bot ni a vendedor agresivo.

REGLAS DE CONVERSACIÓN:
1. Ya te has presentado formalmente en el primer mensaje. En las respuestas siguientes sé conversacional, empático y directo.
2. NUNCA vendas o propongas planes de golpe sin haber escuchado y validado la objeción del usuario.
3. Si el usuario te cuenta su objeción (dinero, tiempo, miedo a no entender el nivel, etc.):
   - Primero empatiza de verdad ("Te entiendo perfectamente...", "A muchos de mis alumnos les pasaba exactamente igual...").
   - Luego ofrece la solución más adecuada justificando el porqué según tu experiencia como MVP y profesor.
4. PLANES DISPONIBLES:
   - Escuela de Excel & Finanzas (197€): Para quienes buscan dominar Excel a fondo, con +50 cursos, soporte VIP y certificación. Incluye la etiqueta [SHOW_CARD: escuela]
   - Excel Intensivo Directo (97€): Para quienes tienen poco tiempo y necesitan soluciones prácticas y plantillas en vivo (3 horas intensivas). Incluye la etiqueta [SHOW_CARD: intensivo]
   - Intensivo Grabado (47€): Para quienes tienen un presupuesto ajustado o quieren ir a su propio ritmo sin presión. Incluye la etiqueta [SHOW_CARD: grabado]

LÓGICA VISUAL:
Cuando recomiendes uno de los planes, pon la etiqueta al final de tu mensaje:
[SHOW_CARD: escuela]
[SHOW_CARD: intensivo]
[SHOW_CARD: grabado]

HISTORIAL Y FECHAS DE LANZAMIENTOS DE EXCELYFINANZAS:
Conoces todas las campañas y fechas de tus lanzamientos:
- 14/09/2023 a 08/10/2023: OlimpiadasSep23
- 15/01/2024 a 08/02/2024: Juegos de Invierno24
- 18/02/2024 a 28/02/2024: Webinar Tablas Dinámicas24
- 10/03/2024 a 02/04/2024: Desafio Dashbords24
- 02/04/2024 a 22/04/2024: El Poder de las Tablas Dinámicas24
- 22/04/2024 a 01/05/2024: Masterclass Chat GPT en Excel
- 15/05/2024 a 12/06/2024: Los 4 Ases del Excel24
- 19/06/2024 a 19/07/2024: Curso Dashboard en Excel24
- 12/07/2024 a 01/08/2024: Webinar Mejores Trucos Julio24
- 04/09/2024 a 02/10/2024: OlimpiadasSep24
- 21/10/2024 a 10/11/2024: Workshop IA en Excel
- 18/11/2024 a 08/12/2024: Green Week24
- 20/01/2025 a 09/02/2025: Juegos de Invierno25
- 10/02/2025 a 10/03/2025: Tablas Dinámicas25
- 17/03/2025 a 05/04/2025: Excel+IA MAR25
- 06/04/2025 a 10/05/2025: CURSO GRATUITO DE EXCEL ABR'25
- 19/05/2025 a 02/06/2025: Tablas Dinámicas MAY25
- 03/06/2025 a 02/07/2025: CURSO INTENSIVO JUL25
- 03/07/2025 a 15/07/2025: LATAM-jul25
- 20/07/2025 a 10/08/2025: LATAM-300725
- 23/08/2025 a 03/09/2025: LATAM-310825
- 08/09/2025 a 03/10/2025: OLIMPIADAS - SEP25
- 12/10/2025 a 29/10/2025: CURSO INTENSIVO OCT25
- 20/10/2025 a 29/10/2025: LATAM-261025
- 03/11/2025 a 23/11/2025: GREEN WEEK NOV25
- 11/01/2026 a 25/01/2026: JUEGOS INVIERNO EN'26
- 15/02/2026 a 05/03/2026: TRUCOS OCULTOS FEB'26
- 08/03/2026 a 30/03/2026: EXCEL + IA WARRIORS MAR'26
- 31/03/2026 a 10/05/2026: ABR26
- 11/05/2026 a 02/06/2026: EXCEL IA POWERBI - MAY´26
- 01/09/2026 a 10/10/2026: OLIMPIADAS EXCEL - SEP26
Si el usuario menciona una fecha, reconoce inmediatamente a qué lanzamiento asistió.
`;

export class SetterService {
  private chat: Chat | null = null;
  private ai: GoogleGenAI | null = null;
  private currentLeadName: string = 'Juan';
  private currentDaysAgo: number = 4;
  private currentEventName: string = 'los Juegos de Invierno de Excel';

  constructor() {
    const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || '';
    if (apiKey) {
      try {
        this.ai = new GoogleGenAI({ apiKey });
      } catch (err) {
        console.warn("Could not initialize GoogleGenAI with provided key", err);
      }
    }
  }

  private initChat(leadName: string, daysAgo: number, eventName: string) {
    this.currentLeadName = leadName;
    this.currentDaysAgo = daysAgo;
    this.currentEventName = eventName;

    if (!this.ai) {
      const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || '';
      if (apiKey) {
        try {
          this.ai = new GoogleGenAI({ apiKey });
        } catch (err) {
          console.warn("Could not initialize GoogleGenAI", err);
        }
      }
    }

    if (this.ai) {
      try {
        const initialText = buildInitialMessage(leadName, daysAgo, eventName);
        this.chat = this.ai.chats.create({
          model: 'gemini-3.8-flash',
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.7,
          },
          history: [
            {
              role: 'user',
              parts: [{ text: `[Contexto del chat: El lead se llama ${leadName} y asistió a los directos de ${eventName}]` }],
            },
            {
              role: 'model',
              parts: [{ text: initialText }],
            },
          ],
        });
      } catch (e) {
        console.warn("Failed to create Gemini chat session, falling back to local handler", e);
        this.chat = null;
      }
    }
  }

  async startConversation(
    leadName: string = 'Juan',
    daysAgo: number = 4,
    eventName: string = 'los Juegos de Invierno de Excel'
  ): Promise<Message> {
    this.initChat(leadName, daysAgo, eventName);
    const initialText = buildInitialMessage(leadName, daysAgo, eventName);

    return {
      id: Date.now().toString(),
      role: 'assistant',
      text: initialText,
      timestamp: new Date(),
    };
  }

  async sendMessage(text: string): Promise<Message> {
    if (this.chat) {
      try {
        const response = await this.chat.sendMessage({ message: text });
        if (response.text) {
          return this.processResponse(response.text);
        }
      } catch (error) {
        console.error("Gemini API call failed, using intelligent fallback", error);
      }
    }

    // Intelligent fallback as Miguel MVP in case of API issues or missing key
    return this.getFallbackResponse(text);
  }

  private getFallbackResponse(userInput: string): Message {
    const lower = userInput.toLowerCase();
    let replyText = "";
    let productCard: Message['productCard'] = undefined;

    // Check if user specified a date (e.g., DD/MM/YYYY or DD-MM-YYYY)
    const dateMatch = userInput.match(/\b\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}\b/);
    if (dateMatch) {
      const detected = findCampaignByDate(dateMatch[0]);
      if (detected) {
        replyText = `¡Exacto, ${this.currentLeadName}! Por esa fecha (${dateMatch[0]}) estábamos con los directos de **${detected.campaign.name}** (del ${detected.campaign.startDate} al ${detected.campaign.endDate}).

Recuerdo muy bien esa edición, vimos trucos clave que a la gente le volaron la cabeza. Me quedé con las ganas de tenerte dentro de la comunidad de alumnos para ayudarte a aplicarlo todo a tu caso real. ¿Qué fue lo que más te gustó de esos directos o qué te impidió dar el paso final? 😊`;
        return {
          id: Date.now().toString(),
          role: 'assistant',
          text: replyText,
          timestamp: new Date(),
        };
      }
    }

    if (lower.includes("precio") || lower.includes("dinero") || lower.includes("caro") || lower.includes("presupuesto") || lower.includes("pasta") || lower.includes("pagar")) {
      replyText = `Te entiendo perfectamente, ${this.currentLeadName}. Es totalmente normal que una inversión te haga dudar si no contabas con ella en este momento.

Mi prioridad como mentor y desde ExcelyFinanzas es que la parte económica nunca sea la razón para frenar tu crecimiento profesional. 

Si la Escuela al completo se te escapa ahora, he preparado una alternativa con acceso directo a todo el contenido grabado paso a paso por solo 47€, para que puedas avanzar a tu propio ritmo sin agobios. ¿Cómo lo ves?`;
      productCard = 'grabado';
    } else if (lower.includes("tiempo") || lower.includes("ocupado") || lower.includes("trabajo") || lower.includes("horario") || lower.includes("hijos") || lower.includes("familia")) {
      replyText = `Totalmente comprensible, ${this.currentLeadName}. El 90% de los profesionales que entran a ExcelyFinanzas me dicen exactamente lo mismo: sienten que no tienen horas en el día.

Precisamente por eso el objetivo es ahorrarte tiempo: dominar las fórmulas y atajos clave te devuelve 5 horas semanales de trabajo repetitivo.

Para casos como el tuyo diseñamos el Intensivo en Directo de solo 3 horas: directo al grano, con las plantillas ya hechas para aplicar al día siguiente. ¿Te cuadraría algo así de concentrado?`;
      productCard = 'intensivo';
    } else if (lower.includes("nivel") || lower.includes("miedo") || lower.includes("avanzado") || lower.includes("básico") || lower.includes("difícil") || lower.includes("no sé si podré")) {
      replyText = `¡Qué bueno que me lo dices, ${this.currentLeadName}! Mucha gente piensa que necesita una base matemática o de programación para dar el salto, pero la realidad es que en la Escuela empezamos desde cero y vamos construyendo con casos reales.

Además tienes soporte VIP con mi equipo y conmigo para resolver cualquier duda que te surja con tus propios archivos de trabajo. Nunca estás solo en el proceso.`;
      productCard = 'escuela';
    } else {
      replyText = `Te agradezco un montón la sinceridad, ${this.currentLeadName}. Justo por eso te escribía de forma personal: como MVP de Microsoft Excel y al frente de ExcelyFinanzas, me importa mucho saber qué necesitáis para mejorar vuestro día a día.

Cuéntame un poquito más sobre qué tipo de tareas haces en tu trabajo o qué dudas te quedaron tras los directos, y vemos juntos si te merece la pena o cómo podemos ayudarte. ¡Cero compromiso, de verdad! 😊`;
    }

    return {
      id: Date.now().toString(),
      role: 'assistant',
      text: replyText,
      timestamp: new Date(),
      productCard
    };
  }

  private processResponse(rawText: string): Message {
    let text = rawText;
    let productCard: Message['productCard'] = undefined;

    if (text.includes('[SHOW_CARD: escuela]')) {
      productCard = 'escuela';
      text = text.replace('[SHOW_CARD: escuela]', '').trim();
    } else if (text.includes('[SHOW_CARD: intensivo]')) {
      productCard = 'intensivo';
      text = text.replace('[SHOW_CARD: intensivo]', '').trim();
    } else if (text.includes('[SHOW_CARD: grabado]')) {
      productCard = 'grabado';
      text = text.replace('[SHOW_CARD: grabado]', '').trim();
    }

    return {
      id: Date.now().toString(),
      role: 'assistant',
      text,
      timestamp: new Date(),
      productCard
    };
  }
}

export const setterService = new SetterService();

