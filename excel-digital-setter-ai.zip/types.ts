
export type MessageRole = 'assistant' | 'user' | 'system';

export interface Message {
  id: string;
  role: MessageRole;
  text: string;
  timestamp: Date;
  imageUrl?: string;
  productCard?: 'escuela' | 'intensivo' | 'grabado';
}

export interface LeadInfo {
  name: string;
  lastEvent: string;
  daysSinceEvent?: number;
  status: 'pending' | 'engaging' | 'converted' | 'lost';
}

export enum ObjectionType {
  ECONOMIC = 'ECONOMIC',
  TIME = 'TIME',
  OTHER = 'OTHER',
  NONE = 'NONE'
}
